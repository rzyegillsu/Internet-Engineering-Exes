# Simple TODO List (MVC + EJS + MongoDB)

پروژه‌ی تمرینی برای پیاده‌سازی کامل الگوی MVC با Express، موتور قالب EJS، اتصال به MongoDB Atlas و کش کردن درخواست‌ها با Node Cache. امکانات اصلی:

- 🎯 CRUD کامل (ایجاد، خواندن، ویرایش، حذف)
- 🔍 فیلتر بر اساس وضعیت و جستجو بر اساس عنوان
- ⚡️ کش سمت سرور با `node-cache` (قابل تنظیم از طریق `.env`)
- 🧱 ساختار پوشه‌بندی تمیز و ماژولار (config، controllers، models، routes، views)
- 🎨 رابط کاربری ساده با EJS + express-ejs-layouts + CSS سفارشی

## راه‌اندازی

```bash
cp .env.example .env
# مقدار MONGODB_URI را با رشته اتصال MongoDB Atlas خود جایگزین کنید
npm install
npm run dev
```

> سرور به صورت پیش‌فرض روی آدرس <http://localhost:3000> بالا می‌آید.
> برای اجرای بدون Mongo (تست سریع)، می‌توانید متغیر `SKIP_DB=true` را هنگام اجرای اسکریپت تنظیم کنید.

## اسکریپت‌ها

| دستور | توضیح |
| --- | --- |
| `npm start` | اجرای برنامه در محیط production |
| `npm run dev` | اجرای برنامه با nodemon برای توسعه |

## ساختار پروژه

```
config/         ── اتصال به MongoDB
controllers/    ── منطق تجاری Todo + Caching
models/         ── مدل Mongoose
routes/         ── تعریف مسیرهای CRUD
views/          ── قالب‌های EJS + layout اصلی
public/         ── استایل‌های CSS
```

## تنظیمات فیلتر و جستجو

- پارامتر `status` با مقادیر `pending | done`
- پارامتر `search` برای تطابق متنی (Case-Insensitive)

## کش

- از `node-cache` با مقدار TTL پیش‌فرض ۲۰ ثانیه استفاده شده است.
- با هر عملیات تغییر دهنده داده (Add/Update/Delete) کش تخلیه می‌شود.
- می‌توانید TTL را از طریق متغیر محیطی `CACHE_TTL` تنظیم کنید.

## نکات تولیدی

- اتصال به MongoDB Atlas باید از طریق IP Whitelist و کاربر امن انجام شود.
- برای دپلوی روی سرویس‌های ابری، کافیست متغیرهای محیطی را مطابق `.env.example` تنظیم و `npm start` را اجرا کنید.
